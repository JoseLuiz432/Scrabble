from copy import copy


class Maquina(object):

    def __init__(self, gerente, jogador, solve):
        self.__jogador = jogador
        self.__gerente = gerente
        self.__solve = solve

    def montar_letras(self):
        minhas_letras = self.__jogador.letras
        palavras_tabuleiro = self.pegar_tabuleiro()
        return self.backtracking(minhas_letras, palavras_tabuleiro)

    def pegar_tabuleiro(self):
        x, y = self.__gerente.pegar_palavras_tabuleiro()
        r = (x, y)
        return r

    def backtracking(self, letras, tabuleiro):
        horizontais = tabuleiro[0][0]
        pos_ho = tabuleiro[0][1]
        pos_ve = tabuleiro[1][1]
        verticais = tabuleiro[1][0]
        cont = 0
        if ' ' in letras:
            letras.remove(' ')
            letras.append('a')
        if not(horizontais and verticais):
            l = []
            self.perm(''.join(letras) + ' ', l)
            provisorio = self.__solve.retorno_palavras(''.join(letras))

            b = ''
            for i in l:
                p = i
                if ' ' in i:
                    i = i.split(' ')
                    p = i[0]
                    b = i[1]
                if p in provisorio:
                    s, word, erro = self.__gerente.inserir_tabuleiro(p, 7, 7, 'v')
                    if not s:
                        print(erro)
                        input()
                        continue

                    return True, word, 7, 7, 'v'
                elif b in provisorio:
                    s, word, erro = self.__gerente.inserir_tabuleiro(b, 7, 7, 'v')
                    if not s:
                        print(erro)
                        input()
                        continue

                    return True, word, 7, 7, 'v'
        for hor in horizontais:
            qnt_antes = 0
            qnt_depois = 0
            flag = False
            h = ''
            pos_h = pos_ho[cont]
            cont += 1
            for i in hor:
                if i != 0:
                    h += i
                else:
                    if flag:
                        qnt_depois += 1
                    else:
                        qnt_antes += 1

            prov_antes = copy(letras) + [' ']
            prov_depois = copy(letras) + [" "]
            left = []
            right = []
            self.perm(''.join(prov_antes), left)

            provisorio = self.__solve.retorno_palavras(h + ''.join(letras))

            for l in left:
                l = l.split(' ')
                for r in left:
                    r = r.split(' ')
                    for opcao in range(2):
                        for opcao2 in range(2):
                            p = l[opcao] + h + r[opcao2]
                            if p == h:
                                continue
                            if p in provisorio:
                                inserir = ''
                                for i in l[opcao]:
                                    inserir += i
                                for j in h:
                                    inserir += 'k'
                                for z in r[opcao2]:
                                    inserir += z
                                print(inserir)
                                print(pos_h[1] - len(l[opcao]))
                                s, word, erro = self.__gerente.inserir_tabuleiro(inserir, pos_h[0], pos_h[1] - len(l[opcao]), 'h')
                                if not s:
                                    print(erro)
                                    input()
                                    continue

                                return True, word, pos_h[0], pos_h[1] - len(l[opcao]), 'h'
        cont = 0
        for ver in verticais:
            v = ''
            flag = False
            qnt_depois = 0
            qnt_antes = 0
            pos_h = pos_ve[cont]
            cont += 1
            for i in ver:
                if i != 0:
                    v += i
                else:
                    if flag:
                        qnt_depois += 1
                    else:
                        qnt_antes += 1

            prov_antes = copy(letras) + [' ']
            prov_depois = copy(letras) + [" "]
            left = []
            right = []
            self.perm(''.join(prov_antes), left)
            provisorio = self.__solve.retorno_palavras(v+''.join(letras))
            for l in left:
                l = l.split(' ')
                for r in left:
                    r = r.split(' ')
                    for opcao in range(2):
                        for opcao2 in range(2):
                            p = l[opcao] + v + r[opcao2]
                            if p == v:
                                continue
                            print(p)
                            if p in provisorio:
                                inserir = ''
                                for i in l[opcao]:
                                    inserir += i
                                for j in v:
                                    inserir += 'k'
                                for z in r[opcao2]:
                                    inserir += z
                                print(inserir)
                                print(pos_h[0] - len(l[opcao]))
                                s, word, erro = self.__gerente.inserir_tabuleiro(inserir, pos_h[0] - len(l[opcao]), pos_h[1] , 'v')
                                if not s:
                                    print(erro)
                                    input()
                                    continue

                                return True, word, pos_h[0], pos_h[1] - len(l[opcao]), 'v'

        return False, 0, 0, ''

    def perm(self, s, lista, i=0):
        if i == len(s) - 1:
            lista.append(s)
        else:
            for j in range(i, len(s)):
                t = s
                s = s[j] + s[:j] + s[(j + 1):]
                self.perm(s, lista, i + 1)
                s = t
